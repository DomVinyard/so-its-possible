import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { StateMachineProvider, createStore } from "little-state-machine";
import { DevTool } from "little-state-machine-devtools";
import Step1 from "./pages/Step1";
import Step2 from "./pages/Step2";
import Result from "./Result";

import "./styles.css";

createStore({
  yourDetails: {
    firstName: "",
    lastName: "",
    age: "",
    yearsOfExp: ""
  }
});

const Pages = () => (
  <>
    <Route exact path="/" component={Step1} />
    <Route path="/step2" component={Step2} />
    <Route path="/result" component={Result} />
  </>
);

function App() {
  return (
    <StateMachineProvider>
      <DevTool />
      <div className="container">
        <h1>Form Wizzard</h1>

        <Router>
          <Pages />
        </Router>
      </div>
    </StateMachineProvider>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
